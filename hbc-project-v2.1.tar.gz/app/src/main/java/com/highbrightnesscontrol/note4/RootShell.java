package com.highbrightnesscontrol.note4;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

final class RootShell {
    static final class Result {
        final int code; final String out;
        Result(int c, String o) { code = c; out = o; }
        boolean ok() { return code == 0; }
    }

    private static Process shell;
    private static BufferedWriter input;
    private static BufferedReader output;
    private static long sequence;

    static synchronized Result run(String command) {
        Result last = new Result(-1, "root shell unavailable");
        for (int attempt = 0; attempt < 2; attempt++) {
            try {
                ensureShell();
                String marker = "__HBC_RC_" + (++sequence) + "__:";
                input.write(command);
                input.newLine();
                input.write("rc=$?; echo " + marker + "$rc");
                input.newLine();
                input.flush();

                StringBuilder b = new StringBuilder();
                String line;
                while ((line = output.readLine()) != null) {
                    if (line.startsWith(marker)) {
                        int rc;
                        try { rc = Integer.parseInt(line.substring(marker.length()).trim()); }
                        catch (Throwable ignored) { rc = -1; }
                        return new Result(rc, b.toString().trim());
                    }
                    b.append(line).append('\n');
                }
                last = new Result(-1, b.toString().trim());
            } catch (Throwable t) {
                last = new Result(-1, t.toString());
            }
            closeInternal();
        }
        return last;
    }

    private static void ensureShell() throws Exception {
        if (shell != null) {
            try { shell.exitValue(); closeInternal(); }
            catch (IllegalThreadStateException alive) { return; }
        }
        ProcessBuilder pb = new ProcessBuilder("su");
        pb.redirectErrorStream(true);
        shell = pb.start();
        input = new BufferedWriter(new OutputStreamWriter(shell.getOutputStream()));
        output = new BufferedReader(new InputStreamReader(shell.getInputStream()));
    }

    static synchronized void close() { closeInternal(); }

    private static void closeInternal() {
        try { if (input != null) { input.write("exit"); input.newLine(); input.flush(); } } catch (Throwable ignored) {}
        try { if (input != null) input.close(); } catch (Throwable ignored) {}
        try { if (output != null) output.close(); } catch (Throwable ignored) {}
        try { if (shell != null) shell.destroy(); } catch (Throwable ignored) {}
        shell = null;
        input = null;
        output = null;
    }

    static String sq(String s) { return "'" + s.replace("'", "'\"'\"'") + "'"; }
    private RootShell() {}
}
