package com.highbrightnesscontrol.note4;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Prefs.get(context).getBoolean(Prefs.BOOT, false)) {
            context.startService(new Intent(context, HbmService.class));
        }
    }
}
