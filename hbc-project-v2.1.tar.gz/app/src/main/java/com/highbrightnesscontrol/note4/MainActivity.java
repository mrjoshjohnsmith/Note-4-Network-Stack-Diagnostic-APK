package com.highbrightnesscontrol.note4;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int GOLD = Color.rgb(255, 193, 7);
    private static final int WHITE = Color.rgb(245, 245, 245);
    private static final int MUTED = Color.rgb(165, 165, 165);
    private static final int CARD = Color.rgb(15, 15, 15);
    private static final int BORDER = Color.rgb(45, 45, 45);

    private SharedPreferences prefs;
    private TextView chipStatus;
    private TextView luxStatus;
    private TextView sensitivityValue;
    private SeekBar sensitivity;
    private Switch switchMaster, switchForceHbm, switchManualMax, switchThermal, switchTimeout, switchBoot;
    private boolean loading;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!HbmService.ACTION_STATE.equals(intent.getAction())) return;
            String s = intent.getStringExtra(HbmService.EXTRA_STATE);
            float lux = intent.getFloatExtra(HbmService.EXTRA_LUX, -1f);
            float eff = intent.getFloatExtra(HbmService.EXTRA_EFFECTIVE_LUX, -1f);
            chipStatus.setText(s == null ? "READY" : s);
            if (lux >= 0f && eff >= 0f) {
                luxStatus.setText(String.format(Locale.US, "Ambient: %.0f lux   ·   Effective HBM light: %.0f lux", lux, eff));
            } else {
                luxStatus.setText("Ambient light sensor: waiting for reading");
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = Prefs.get(this);
        buildUi();
        loadPrefs();
    }

    @Override protected void onResume() {
        super.onResume();
        registerReceiver(stateReceiver, new IntentFilter(HbmService.ACTION_STATE));
        startService(new Intent(this, HbmService.class));
    }

    @Override protected void onPause() {
        try { unregisterReceiver(stateReceiver); } catch (Throwable ignored) {}
        super.onPause();
    }

    private void buildUi() {
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.BLACK);
        LinearLayout root = vertical();
        root.setPadding(dp(18), dp(20), dp(18), dp(30));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        LinearLayout header = horizontal();
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("HIGH BRIGHTNESS CONTROL", 21, WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        chipStatus = chip("IDLE");
        header.addView(chipStatus);
        root.addView(header);

        TextView sub = text("Galaxy Note 4 · SM-N910V · High Brightness Mode", 12, MUTED);
        LinearLayout.LayoutParams subLp = lp(-1, -2, 0, 7, 0, 18);
        root.addView(sub, subLp);

        LinearLayout mainCard = card();
        TextView cardTitle = text("Unlock HBM", 18, WHITE);
        cardTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        mainCard.addView(cardTitle);
        TextView desc = text("Use Samsung's real HBM path while keeping the ambient light sensor and normal automatic brightness intact.", 13, MUTED);
        mainCard.addView(desc, lp(-1, -2, 0, 5, 0, 10));

        switchMaster = sw("Enable High Brightness Control");
        mainCard.addView(switchMaster);
        TextView masterHelp = text("Master switch for light sensitivity, Manual Max is HBM, and Force HBM.", 12, MUTED);
        mainCard.addView(masterHelp, lp(-1, -2, 0, 0, 0, 4));

        switchForceHbm = sw("Force HBM continuously");
        mainCard.addView(switchForceHbm);
        TextView forceHelp = text("Keeps Samsung HBM asserted regardless of automatic/manual mode or brightness-slider position until you turn it off.", 12, MUTED);
        mainCard.addView(forceHelp, lp(-1, -2, 0, 0, 0, 4));

        TextView sensTitle = text("Light sensitivity", 15, WHITE);
        sensTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        mainCard.addView(sensTitle, lp(-1, -2, 0, 14, 0, 0));

        LinearLayout sensRow = horizontal();
        TextView zero = text("0%", 12, MUTED);
        TextView five = text("2000%", 12, MUTED);
        sensitivityValue = text("100%", 16, GOLD);
        sensitivityValue.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        sensitivityValue.setGravity(Gravity.CENTER);
        sensRow.addView(zero, new LinearLayout.LayoutParams(0, -2, 1f));
        sensRow.addView(sensitivityValue, new LinearLayout.LayoutParams(0, -2, 1f));
        sensRow.addView(five, new LinearLayout.LayoutParams(0, -2, 1f));
        five.setGravity(Gravity.RIGHT);
        mainCard.addView(sensRow, lp(-1, -2, 0, 5, 0, 0));

        sensitivity = new SeekBar(this);
        sensitivity.setMax(2000);
        mainCard.addView(sensitivity, lp(-1, -2, 0, 0, 0, 0));

        TextView scaleHelp = text("100% = Samsung stock HBM behavior. 500% uses one-fifth the reference light level; 2000% uses one-twentieth. 50% requires twice as much light. 0% blocks light-triggered HBM. The real sensor reading is never spoofed.", 12, MUTED);
        mainCard.addView(scaleHelp, lp(-1, -2, 0, 3, 0, 10));

        luxStatus = text("Ambient light sensor: waiting for reading", 12, GOLD);
        mainCard.addView(luxStatus, lp(-1, -2, 0, 0, 0, 10));

        switchManualMax = sw("Manual max is HBM");
        switchThermal = sw("Disable heat throttle");
        switchTimeout = sw("Disable time limit");
        switchBoot = sw("Start on boot");
        mainCard.addView(switchManualMax);
        mainCard.addView(switchThermal);
        mainCard.addView(switchTimeout);
        mainCard.addView(switchBoot);

        root.addView(mainCard, lp(-1, -2, 0, 0, 0, 14));

        LinearLayout actionCard = card();
        TextView aTitle = text("Control", 16, WHITE);
        aTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        actionCard.addView(aTitle);
        LinearLayout buttons = horizontal();
        Button scan = button("SCAN");
        Button apply = button("APPLY");
        buttons.addView(scan, new LinearLayout.LayoutParams(0, dp(48), 1f));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, dp(48), 1f);
        ap.setMargins(dp(10), 0, 0, 0);
        buttons.addView(apply, ap);
        actionCard.addView(buttons, lp(-1, -2, 0, 12, 0, 0));
        root.addView(actionCard, lp(-1, -2, 0, 0, 0, 14));

        LinearLayout warning = card();
        TextView warningTitle = text("AMOLED protection", 15, GOLD);
        warningTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        warning.addView(warningTitle);
        TextView warningBody = text("HBM substantially increases OLED current, power draw and panel temperature. “Disable heat throttle” and “Disable time limit” intentionally bypass Samsung safeguards and can accelerate image retention, burn-in or panel wear. The app no longer makes SELinux globally permissive.", 12, MUTED);
        warning.addView(warningBody, lp(-1, -2, 0, 6, 0, 0));
        root.addView(warning);

        setContentView(scroll);

        CompoundButton.OnCheckedChangeListener listener = new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (loading) return;
                String key;
                if (buttonView == switchMaster) key = Prefs.MASTER;
                else if (buttonView == switchForceHbm) key = Prefs.FORCE_HBM;
                else if (buttonView == switchManualMax) key = Prefs.MANUAL_MAX;
                else if (buttonView == switchThermal) key = Prefs.THERMAL;
                else if (buttonView == switchTimeout) key = Prefs.TIMEOUT;
                else key = Prefs.BOOT;
                prefs.edit().putBoolean(key, isChecked).apply();
                startService(new Intent(MainActivity.this, HbmService.class));
            }
        };
        switchMaster.setOnCheckedChangeListener(listener);
        switchForceHbm.setOnCheckedChangeListener(listener);
        switchManualMax.setOnCheckedChangeListener(listener);
        switchThermal.setOnCheckedChangeListener(listener);
        switchTimeout.setOnCheckedChangeListener(listener);
        switchBoot.setOnCheckedChangeListener(listener);

        sensitivity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                sensitivityValue.setText(progress + "%");
                if (fromUser && !loading) prefs.edit().putInt(Prefs.SENSITIVITY, progress).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                startService(new Intent(MainActivity.this, HbmService.class));
            }
        });

        scan.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                chipStatus.setText("SCANNING");
                Intent i = new Intent(MainActivity.this, HbmService.class);
                i.setAction(HbmService.ACTION_RESCAN);
                startService(i);
            }
        });
        apply.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startService(new Intent(MainActivity.this, HbmService.class));
                chipStatus.setText("APPLIED");
            }
        });
    }

    private void loadPrefs() {
        loading = true;
        switchMaster.setChecked(prefs.getBoolean(Prefs.MASTER, false));
        switchForceHbm.setChecked(prefs.getBoolean(Prefs.FORCE_HBM, false));
        switchManualMax.setChecked(prefs.getBoolean(Prefs.MANUAL_MAX, false));
        switchThermal.setChecked(prefs.getBoolean(Prefs.THERMAL, false));
        switchTimeout.setChecked(prefs.getBoolean(Prefs.TIMEOUT, false));
        switchBoot.setChecked(prefs.getBoolean(Prefs.BOOT, false));
        int s = Math.max(0, Math.min(2000, prefs.getInt(Prefs.SENSITIVITY, 100)));
        sensitivity.setProgress(s);
        sensitivityValue.setText(s + "%");
        loading = false;
    }

    private LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout horizontal() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); return l; }
    private LinearLayout card() {
        LinearLayout l = vertical();
        l.setPadding(dp(16), dp(15), dp(16), dp(15));
        GradientDrawable g = new GradientDrawable();
        g.setColor(CARD); g.setCornerRadius(dp(12)); g.setStroke(dp(1), BORDER);
        l.setBackground(g);
        return l;
    }
    private TextView text(String s, int sp, int color) { TextView t = new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(color); return t; }
    private TextView chip(String s) {
        TextView t = text(s, 11, GOLD); t.setGravity(Gravity.CENTER); t.setPadding(dp(10), dp(5), dp(10), dp(5));
        GradientDrawable g = new GradientDrawable(); g.setColor(Color.rgb(28, 24, 8)); g.setCornerRadius(dp(20)); g.setStroke(dp(1), Color.rgb(90, 74, 8)); t.setBackground(g); return t;
    }
    private Switch sw(String s) { Switch w = new Switch(this); w.setText(s); w.setTextColor(WHITE); w.setTextSize(14); w.setPadding(0, dp(8), 0, dp(8)); return w; }
    private Button button(String s) { Button b = new Button(this); b.setText(s); b.setTextColor(Color.BLACK); b.setTextSize(13); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); GradientDrawable g = new GradientDrawable(); g.setColor(GOLD); g.setCornerRadius(dp(8)); b.setBackground(g); return b; }
    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w,h); p.setMargins(dp(l),dp(t),dp(r),dp(b)); return p; }
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
