package com.highbrightnesscontrol.note4;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HbmService extends Service implements SensorEventListener, SharedPreferences.OnSharedPreferenceChangeListener {
    public static final String ACTION_RESCAN = "com.highbrightnesscontrol.note4.RESCAN";
    public static final String ACTION_STOP = "com.highbrightnesscontrol.note4.STOP";
    public static final String ACTION_STATE = "com.highbrightnesscontrol.note4.STATE";
    public static final String EXTRA_STATE = "state";
    public static final String EXTRA_LUX = "lux";
    public static final String EXTRA_EFFECTIVE_LUX = "effectiveLux";
    public static final String EXTRA_HBM = "hbm";

    private static final float HBM_REFERENCE_LUX = 40000f;
    private static final float HYSTERESIS = 0.80f;
    private static final long CONTROL_MS = 500L;
    private static final long STATE_CHECK_MS = 500L;
    private static final long THERMAL_CHECK_MS = 5000L;

    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private SensorManager sensorManager;
    private Sensor light;

    private volatile float rawLux = -1f;
    private volatile float filteredLux = -1f;
    private volatile boolean lightDemand;
    private volatile boolean manualDemand;
    private volatile boolean appForcedHbm;
    private volatile long lastStateCheck;
    private volatile long lastThermalCheck;
    private volatile int lastNormalAuto = -1;
    private volatile int restoreAuto = -1;
    private volatile String autoBrightnessPath = "";
    private volatile String explicitHbmPath = "";
    private volatile String mdnieOutdoorPath = "";
    private volatile String lastState = "STARTING";
    private volatile boolean rootOk;

    private final Runnable control = new Runnable() {
        @Override public void run() {
            io.execute(new Runnable() { @Override public void run() { controlOnce(); } });
            main.postDelayed(this, CONTROL_MS);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        prefs = Prefs.get(this);
        prefs.registerOnSharedPreferenceChangeListener(this);
        sensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        light = sensorManager == null ? null : sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        if (light != null) sensorManager.registerListener(this, light, SensorManager.SENSOR_DELAY_NORMAL);

        startForeground(4040, buildNotification());
        io.execute(new Runnable() { @Override public void run() { scanPaths(); } });
        main.post(control);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (intent != null && ACTION_RESCAN.equals(intent.getAction())) io.execute(new Runnable() { @Override public void run() { scanPaths(); } });
        return START_STICKY;
    }

    @Override public void onDestroy() {
        main.removeCallbacks(control);
        if (sensorManager != null) sensorManager.unregisterListener(this);
        if (prefs != null) prefs.unregisterOnSharedPreferenceChangeListener(this);
        io.execute(new Runnable() {
            @Override public void run() {
                if (appForcedHbm) releaseHbmOnce();
                RootShell.close();
            }
        });
        io.shutdown();
        stopForeground(true);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onSensorChanged(SensorEvent event) {
        if (event == null || event.values.length == 0) return;
        float v = Math.max(0f, event.values[0]);
        rawLux = v;
        if (filteredLux < 0f) filteredLux = v;
        else filteredLux = filteredLux * 0.75f + v * 0.25f;
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}

    @Override public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        if (Prefs.MASTER.equals(key) && !sharedPreferences.getBoolean(Prefs.MASTER, false) && appForcedHbm) {
            io.execute(new Runnable() { @Override public void run() { releaseHbmOnce(); } });
        }
    }

    private void scanPaths() {
        RootShell.Result id = RootShell.run("id");
        rootOk = id.ok() && id.out.contains("uid=0");
        if (!rootOk) { lastState = "ROOT DENIED"; broadcastState(); return; }

        autoBrightnessPath = firstExisting(new String[]{
                "/sys/class/backlight/panel/auto_brightness",
                "/sys/class/backlight/panel0-backlight/auto_brightness",
                "/sys/class/lcd/panel/auto_brightness"});
        explicitHbmPath = firstExisting(new String[]{
                "/sys/class/backlight/panel/hbm_mode",
                "/sys/class/backlight/panel0-backlight/hbm_mode",
                "/sys/class/lcd/panel/hbm_mode",
                "/sys/class/lcd/panel/hbm",
                "/sys/class/graphics/fb0/hbm"});
        mdnieOutdoorPath = firstExisting(new String[]{
                "/sys/class/mdnie/mdnie/outdoor",
                "/sys/class/mdnie/mdnie/hbm"});

        if (autoBrightnessPath.length() > 0) {
            int a = readInt(autoBrightnessPath, -1);
            if (a >= 0 && a <= 5) lastNormalAuto = a;
        }
        if (autoBrightnessPath.length() == 0 && explicitHbmPath.length() == 0) lastState = "HBM NODE NOT FOUND";
        else lastState = "READY";
        broadcastState();
    }

    private String firstExisting(String[] candidates) {
        StringBuilder c = new StringBuilder("for p in");
        for (String p : candidates) c.append(' ').append(RootShell.sq(p));
        c.append("; do [ -e \"$p\" ] && { echo \"$p\"; break; }; done");
        RootShell.Result r = RootShell.run(c.toString());
        return r.ok() ? r.out.trim() : "";
    }

    private void controlOnce() {
        if (!rootOk || (autoBrightnessPath.length() == 0 && explicitHbmPath.length() == 0)) return;

        boolean master = prefs.getBoolean(Prefs.MASTER, false);
        boolean forceAlways = prefs.getBoolean(Prefs.FORCE_HBM, false);
        int sensitivity = Math.max(0, Math.min(2000, prefs.getInt(Prefs.SENSITIVITY, 100)));
        boolean manualMax = prefs.getBoolean(Prefs.MANUAL_MAX, false);
        boolean disableThermal = prefs.getBoolean(Prefs.THERMAL, false);
        boolean disableTimeout = prefs.getBoolean(Prefs.TIMEOUT, false);
        long now = System.currentTimeMillis();

        manualDemand = false;
        if (master && manualMax) {
            try {
                int mode = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE);
                int b = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
                manualDemand = mode == Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL && b >= 255;
            } catch (Throwable ignored) {}
        }

        boolean previous = lightDemand;
        float lux = filteredLux;
        float effective = lux < 0f ? -1f : lux * (sensitivity / 100f);
        if (!master || lux < 0f) {
            lightDemand = false;
        } else if (sensitivity == 100 || sensitivity == 0) {
            lightDemand = false;
        } else if (!previous) {
            lightDemand = effective >= HBM_REFERENCE_LUX;
        } else {
            lightDemand = effective >= (HBM_REFERENCE_LUX * HYSTERESIS);
        }

        boolean wantHbm = master && (forceAlways || manualDemand || lightDemand);

        int currentAuto = -1;
        int currentExplicit = -1;
        boolean checkState = master && (forceAlways || sensitivity < 100 || disableThermal || disableTimeout);
        if (checkState && now - lastStateCheck >= STATE_CHECK_MS) {
            lastStateCheck = now;
            if (autoBrightnessPath.length() > 0) {
                currentAuto = readInt(autoBrightnessPath, -1);
                if (!appForcedHbm && currentAuto >= 0 && currentAuto <= 5) lastNormalAuto = currentAuto;
            } else if (explicitHbmPath.length() > 0) {
                currentExplicit = readInt(explicitHbmPath, -1);
            }
        }

        boolean stockHbmActive = !appForcedHbm && ((currentAuto == 6) || (autoBrightnessPath.length() == 0 && currentExplicit > 0));
        boolean stockMaintenanceDemand = master && !forceAlways && sensitivity == 100 && disableTimeout
                && filteredLux >= HBM_REFERENCE_LUX;
        if (stockMaintenanceDemand) wantHbm = true;

        if (wantHbm) {
            if (!appForcedHbm) {
                forceHbm(currentAuto);
            } else if ((forceAlways || disableTimeout) && currentAuto >= 0 && currentAuto != 6 && autoBrightnessPath.length() > 0) {
                writeNode(autoBrightnessPath, "6");
            } else if ((forceAlways || disableTimeout) && autoBrightnessPath.length() == 0 && currentExplicit == 0 && explicitHbmPath.length() > 0) {
                writeNode(explicitHbmPath, "1");
            }
        } else if (appForcedHbm) {
            releaseHbmOnce();
        }

        if (master && sensitivity < 100 && !forceAlways && !manualDemand && !lightDemand) {
            if (currentAuto == 6) {
                writeNode(autoBrightnessPath, Integer.toString(lastNormalAuto >= 0 ? lastNormalAuto : 5));
            }
            if (autoBrightnessPath.length() == 0 && currentExplicit > 0) {
                writeNode(explicitHbmPath, "0");
            }
        }

        if (disableThermal && master && (wantHbm || stockHbmActive || appForcedHbm)
                && now - lastThermalCheck >= THERMAL_CHECK_MS) {
            applyThermalBypass();
            lastThermalCheck = now;
        }

        String mode;
        if (!master) mode = "IDLE";
        else if (forceAlways) mode = "HBM · FORCED";
        else if (manualDemand) mode = "HBM · MANUAL MAX";
        else if (lightDemand) mode = "HBM · LIGHT";
        else if (sensitivity == 100) mode = "STOCK AUTO";
        else mode = "AUTO · SCALED";
        if (!mode.equals(lastState)) lastState = mode;
        broadcastState();
    }

    private void forceHbm(int observedAuto) {
        if (!appForcedHbm && autoBrightnessPath.length() > 0) {
            int before = observedAuto >= 0 ? observedAuto : readInt(autoBrightnessPath, -1);
            if (before >= 0 && before <= 5) {
                restoreAuto = before;
                lastNormalAuto = before;
            } else if (before == 6 && restoreAuto < 0) {
                restoreAuto = lastNormalAuto >= 0 ? lastNormalAuto : 5;
            }
        }

        boolean wrote = false;
        if (autoBrightnessPath.length() > 0) {
            int before = observedAuto >= 0 ? observedAuto : -1;
            if (before != 6) wrote |= writeNode(autoBrightnessPath, "6");
            else wrote = true;
        } else if (explicitHbmPath.length() > 0) {
            wrote |= writeNode(explicitHbmPath, "1");
        }
        if (mdnieOutdoorPath.length() > 0) writeNode(mdnieOutdoorPath, "1");
        if (wrote) appForcedHbm = true;
    }

    private void releaseHbmOnce() {
        int normal = restoreAuto >= 0 && restoreAuto <= 5 ? restoreAuto : (lastNormalAuto >= 0 ? lastNormalAuto : 5);
        if (autoBrightnessPath.length() > 0) writeNode(autoBrightnessPath, Integer.toString(normal));
        if (explicitHbmPath.length() > 0) writeNode(explicitHbmPath, "0");
        if (mdnieOutdoorPath.length() > 0) writeNode(mdnieOutdoorPath, "0");
        appForcedHbm = false;
        restoreAuto = -1;
    }

    private void applyThermalBypass() {
        String cmd =
                "for p in '/sys/class/lcd/panel/siop_enable' '/sys/class/backlight/panel/device/lcd/panel/siop_enable'; do " +
                "if [ -e \"$p\" ]; then v=$(cat \"$p\" 2>/dev/null); [ \"$v\" = '0' ] || echo 0 > \"$p\"; break; fi; done; " +
                "for p in '/sys/class/lcd/panel/power_reduce' '/sys/class/backlight/panel/device/lcd/panel/power_reduce'; do " +
                "if [ -e \"$p\" ]; then v=$(cat \"$p\" 2>/dev/null); [ \"$v\" = '0' ] || echo 0 > \"$p\"; break; fi; done; " +
                "for p in '/sys/class/lcd/panel/temperature' '/sys/class/backlight/panel/device/lcd/panel/temperature'; do " +
                "if [ -e \"$p\" ]; then v=$(cat \"$p\" 2>/dev/null); [ \"$v\" = '25' ] || echo 25 > \"$p\"; break; fi; done; " +
                "p='/sys/class/power_supply/battery/siop_level'; if [ -e \"$p\" ]; then v=$(cat \"$p\" 2>/dev/null); [ \"$v\" = '100' ] || echo 100 > \"$p\"; fi";
        RootShell.run(cmd);
    }

    private boolean writeNode(String path, String value) {
        if (path == null || path.length() == 0) return false;
        RootShell.Result r = RootShell.run("echo " + RootShell.sq(value) + " > " + RootShell.sq(path));
        return r.ok();
    }

    private int readInt(String path, int fallback) {
        if (path == null || path.length() == 0) return fallback;
        RootShell.Result r = RootShell.run("cat " + RootShell.sq(path));
        if (!r.ok()) return fallback;
        try { return Integer.parseInt(r.out.trim().split("\\s+")[0]); } catch (Throwable t) { return fallback; }
    }

    private void broadcastState() {
        Intent i = new Intent(ACTION_STATE);
        i.setPackage(getPackageName());
        i.putExtra(EXTRA_STATE, lastState);
        i.putExtra(EXTRA_LUX, rawLux);
        int s = prefs == null ? 100 : Math.max(0, Math.min(2000, prefs.getInt(Prefs.SENSITIVITY, 100)));
        i.putExtra(EXTRA_EFFECTIVE_LUX, filteredLux < 0 ? -1f : filteredLux * (s / 100f));
        i.putExtra(EXTRA_HBM, appForcedHbm);
        sendBroadcast(i);
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this)
                .setSmallIcon(R.drawable.ic_stat_sun)
                .setContentTitle("High Brightness Control")
                .setContentText("HBM controller active")
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
    }
}
