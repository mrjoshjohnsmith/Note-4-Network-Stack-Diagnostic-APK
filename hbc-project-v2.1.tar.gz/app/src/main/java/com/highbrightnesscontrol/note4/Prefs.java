package com.highbrightnesscontrol.note4;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    static final String NAME = "high_brightness_control";
    static final String MASTER = "master";
    static final String FORCE_HBM = "force_hbm";
    static final String SENSITIVITY = "light_sensitivity";
    static final String MANUAL_MAX = "manual_max";
    static final String THERMAL = "disable_heat_throttle";
    static final String TIMEOUT = "disable_time_limit";
    static final String BOOT = "start_on_boot";
    static SharedPreferences get(Context c) { return c.getSharedPreferences(NAME, Context.MODE_PRIVATE); }
    static int sensitivity(Context c) { return get(c).getInt(SENSITIVITY, 100); }
    private Prefs() {}
}
